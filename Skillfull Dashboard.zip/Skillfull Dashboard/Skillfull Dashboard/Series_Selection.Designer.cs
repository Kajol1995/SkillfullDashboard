﻿
using System;

namespace Skillfull_Dashboard
{
    partial class Series_Selection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Serieslabel10 = new System.Windows.Forms.Label();
            this.Serieslabel5 = new System.Windows.Forms.Label();
            this.SeriescheckBox9 = new System.Windows.Forms.CheckBox();
            this.SeriescheckBox10 = new System.Windows.Forms.CheckBox();
            this.Serieslabel9 = new System.Windows.Forms.Label();
            this.Serieslabel8 = new System.Windows.Forms.Label();
            this.Serieslabel7 = new System.Windows.Forms.Label();
            this.Serieslabel6 = new System.Windows.Forms.Label();
            this.Serieslabel4 = new System.Windows.Forms.Label();
            this.Serieslabel3 = new System.Windows.Forms.Label();
            this.Serieslabel2 = new System.Windows.Forms.Label();
            this.Serieslabel1 = new System.Windows.Forms.Label();
            this.SeriescheckBox4 = new System.Windows.Forms.CheckBox();
            this.SeriescheckBox7 = new System.Windows.Forms.CheckBox();
            this.SeriescheckBox8 = new System.Windows.Forms.CheckBox();
            this.SeriescheckBox6 = new System.Windows.Forms.CheckBox();
            this.SeriescheckBox5 = new System.Windows.Forms.CheckBox();
            this.SeriescheckBox3 = new System.Windows.Forms.CheckBox();
            this.SeriescheckBox2 = new System.Windows.Forms.CheckBox();
            this.SeriescheckBox1 = new System.Windows.Forms.CheckBox();
            this.SeriesClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Serieslabel10);
            this.groupBox1.Controls.Add(this.Serieslabel5);
            this.groupBox1.Controls.Add(this.SeriescheckBox9);
            this.groupBox1.Controls.Add(this.SeriescheckBox10);
            this.groupBox1.Controls.Add(this.Serieslabel9);
            this.groupBox1.Controls.Add(this.Serieslabel8);
            this.groupBox1.Controls.Add(this.Serieslabel7);
            this.groupBox1.Controls.Add(this.Serieslabel6);
            this.groupBox1.Controls.Add(this.Serieslabel4);
            this.groupBox1.Controls.Add(this.Serieslabel3);
            this.groupBox1.Controls.Add(this.Serieslabel2);
            this.groupBox1.Controls.Add(this.Serieslabel1);
            this.groupBox1.Controls.Add(this.SeriescheckBox4);
            this.groupBox1.Controls.Add(this.SeriescheckBox7);
            this.groupBox1.Controls.Add(this.SeriescheckBox8);
            this.groupBox1.Controls.Add(this.SeriescheckBox6);
            this.groupBox1.Controls.Add(this.SeriescheckBox5);
            this.groupBox1.Controls.Add(this.SeriescheckBox3);
            this.groupBox1.Controls.Add(this.SeriescheckBox2);
            this.groupBox1.Controls.Add(this.SeriescheckBox1);
            this.groupBox1.Location = new System.Drawing.Point(23, 54);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1054, 333);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // Serieslabel10
            // 
            this.Serieslabel10.AutoSize = true;
            this.Serieslabel10.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serieslabel10.Location = new System.Drawing.Point(756, 227);
            this.Serieslabel10.Name = "Serieslabel10";
            this.Serieslabel10.Size = new System.Drawing.Size(70, 22);
            this.Serieslabel10.TabIndex = 19;
            this.Serieslabel10.Text = "Series4";
            // 
            // Serieslabel5
            // 
            this.Serieslabel5.AutoSize = true;
            this.Serieslabel5.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serieslabel5.Location = new System.Drawing.Point(756, 140);
            this.Serieslabel5.Name = "Serieslabel5";
            this.Serieslabel5.Size = new System.Drawing.Size(70, 22);
            this.Serieslabel5.TabIndex = 18;
            this.Serieslabel5.Text = "Series4";
            // 
            // SeriescheckBox9
            // 
            this.SeriescheckBox9.AutoSize = true;
            this.SeriescheckBox9.Location = new System.Drawing.Point(778, 106);
            this.SeriescheckBox9.Name = "SeriescheckBox9";
            this.SeriescheckBox9.Size = new System.Drawing.Size(18, 17);
            this.SeriescheckBox9.TabIndex = 17;
            this.SeriescheckBox9.UseVisualStyleBackColor = true;
            // 
            // SeriescheckBox10
            // 
            this.SeriescheckBox10.AutoSize = true;
            this.SeriescheckBox10.Location = new System.Drawing.Point(778, 188);
            this.SeriescheckBox10.Name = "SeriescheckBox10";
            this.SeriescheckBox10.Size = new System.Drawing.Size(18, 17);
            this.SeriescheckBox10.TabIndex = 16;
            this.SeriescheckBox10.UseVisualStyleBackColor = true;
            // 
            // Serieslabel9
            // 
            this.Serieslabel9.AutoSize = true;
            this.Serieslabel9.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serieslabel9.Location = new System.Drawing.Point(602, 227);
            this.Serieslabel9.Name = "Serieslabel9";
            this.Serieslabel9.Size = new System.Drawing.Size(70, 22);
            this.Serieslabel9.TabIndex = 15;
            this.Serieslabel9.Text = "Series3";
            // 
            // Serieslabel8
            // 
            this.Serieslabel8.AutoSize = true;
            this.Serieslabel8.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serieslabel8.Location = new System.Drawing.Point(447, 227);
            this.Serieslabel8.Name = "Serieslabel8";
            this.Serieslabel8.Size = new System.Drawing.Size(70, 22);
            this.Serieslabel8.TabIndex = 14;
            this.Serieslabel8.Text = "Series2";
            this.Serieslabel8.Click += new System.EventHandler(this.Seriesclose_Click);
            // 
            // Serieslabel7
            // 
            this.Serieslabel7.AutoSize = true;
            this.Serieslabel7.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serieslabel7.Location = new System.Drawing.Point(288, 227);
            this.Serieslabel7.Name = "Serieslabel7";
            this.Serieslabel7.Size = new System.Drawing.Size(70, 22);
            this.Serieslabel7.TabIndex = 13;
            this.Serieslabel7.Text = "Series1";
            // 
            // Serieslabel6
            // 
            this.Serieslabel6.AutoSize = true;
            this.Serieslabel6.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serieslabel6.Location = new System.Drawing.Point(141, 227);
            this.Serieslabel6.Name = "Serieslabel6";
            this.Serieslabel6.Size = new System.Drawing.Size(70, 22);
            this.Serieslabel6.TabIndex = 12;
            this.Serieslabel6.Text = "Series0";
            // 
            // Serieslabel4
            // 
            this.Serieslabel4.AutoSize = true;
            this.Serieslabel4.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serieslabel4.Location = new System.Drawing.Point(602, 140);
            this.Serieslabel4.Name = "Serieslabel4";
            this.Serieslabel4.Size = new System.Drawing.Size(70, 22);
            this.Serieslabel4.TabIndex = 11;
            this.Serieslabel4.Text = "Series3";
            // 
            // Serieslabel3
            // 
            this.Serieslabel3.AutoSize = true;
            this.Serieslabel3.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serieslabel3.Location = new System.Drawing.Point(447, 140);
            this.Serieslabel3.Name = "Serieslabel3";
            this.Serieslabel3.Size = new System.Drawing.Size(70, 22);
            this.Serieslabel3.TabIndex = 10;
            this.Serieslabel3.Text = "Series2";
            // 
            // Serieslabel2
            // 
            this.Serieslabel2.AutoSize = true;
            this.Serieslabel2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serieslabel2.Location = new System.Drawing.Point(288, 140);
            this.Serieslabel2.Name = "Serieslabel2";
            this.Serieslabel2.Size = new System.Drawing.Size(70, 22);
            this.Serieslabel2.TabIndex = 9;
            this.Serieslabel2.Text = "Series1";
            // 
            // Serieslabel1
            // 
            this.Serieslabel1.AutoSize = true;
            this.Serieslabel1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serieslabel1.Location = new System.Drawing.Point(141, 140);
            this.Serieslabel1.Name = "Serieslabel1";
            this.Serieslabel1.Size = new System.Drawing.Size(70, 22);
            this.Serieslabel1.TabIndex = 8;
            this.Serieslabel1.Text = "Series0";
            // 
            // SeriescheckBox4
            // 
            this.SeriescheckBox4.AutoSize = true;
            this.SeriescheckBox4.Location = new System.Drawing.Point(624, 106);
            this.SeriescheckBox4.Name = "SeriescheckBox4";
            this.SeriescheckBox4.Size = new System.Drawing.Size(18, 17);
            this.SeriescheckBox4.TabIndex = 7;
            this.SeriescheckBox4.UseVisualStyleBackColor = true;
            // 
            // SeriescheckBox7
            // 
            this.SeriescheckBox7.AutoSize = true;
            this.SeriescheckBox7.Location = new System.Drawing.Point(467, 188);
            this.SeriescheckBox7.Name = "SeriescheckBox7";
            this.SeriescheckBox7.Size = new System.Drawing.Size(18, 17);
            this.SeriescheckBox7.TabIndex = 6;
            this.SeriescheckBox7.UseVisualStyleBackColor = true;
            // 
            // SeriescheckBox8
            // 
            this.SeriescheckBox8.AutoSize = true;
            this.SeriescheckBox8.Location = new System.Drawing.Point(624, 188);
            this.SeriescheckBox8.Name = "SeriescheckBox8";
            this.SeriescheckBox8.Size = new System.Drawing.Size(18, 17);
            this.SeriescheckBox8.TabIndex = 5;
            this.SeriescheckBox8.UseVisualStyleBackColor = true;
            // 
            // SeriescheckBox6
            // 
            this.SeriescheckBox6.AutoSize = true;
            this.SeriescheckBox6.Location = new System.Drawing.Point(305, 188);
            this.SeriescheckBox6.Name = "SeriescheckBox6";
            this.SeriescheckBox6.Size = new System.Drawing.Size(18, 17);
            this.SeriescheckBox6.TabIndex = 4;
            this.SeriescheckBox6.UseVisualStyleBackColor = true;
            // 
            // SeriescheckBox5
            // 
            this.SeriescheckBox5.AutoSize = true;
            this.SeriescheckBox5.Location = new System.Drawing.Point(160, 188);
            this.SeriescheckBox5.Name = "SeriescheckBox5";
            this.SeriescheckBox5.Size = new System.Drawing.Size(18, 17);
            this.SeriescheckBox5.TabIndex = 3;
            this.SeriescheckBox5.UseVisualStyleBackColor = true;
            // 
            // SeriescheckBox3
            // 
            this.SeriescheckBox3.AutoSize = true;
            this.SeriescheckBox3.Location = new System.Drawing.Point(467, 106);
            this.SeriescheckBox3.Name = "SeriescheckBox3";
            this.SeriescheckBox3.Size = new System.Drawing.Size(18, 17);
            this.SeriescheckBox3.TabIndex = 2;
            this.SeriescheckBox3.UseVisualStyleBackColor = true;
            // 
            // SeriescheckBox2
            // 
            this.SeriescheckBox2.AutoSize = true;
            this.SeriescheckBox2.Location = new System.Drawing.Point(305, 106);
            this.SeriescheckBox2.Name = "SeriescheckBox2";
            this.SeriescheckBox2.Size = new System.Drawing.Size(18, 17);
            this.SeriescheckBox2.TabIndex = 1;
            this.SeriescheckBox2.UseVisualStyleBackColor = true;
            // 
            // SeriescheckBox1
            // 
            this.SeriescheckBox1.AutoSize = true;
            this.SeriescheckBox1.Location = new System.Drawing.Point(160, 106);
            this.SeriescheckBox1.Name = "SeriescheckBox1";
            this.SeriescheckBox1.Size = new System.Drawing.Size(18, 17);
            this.SeriescheckBox1.TabIndex = 0;
            this.SeriescheckBox1.UseVisualStyleBackColor = true;
            // 
            // SeriesClose
            // 
            this.SeriesClose.BackColor = System.Drawing.Color.DarkGray;
            this.SeriesClose.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SeriesClose.Location = new System.Drawing.Point(1002, 414);
            this.SeriesClose.Name = "SeriesClose";
            this.SeriesClose.Size = new System.Drawing.Size(75, 52);
            this.SeriesClose.TabIndex = 1;
            this.SeriesClose.Text = "Close";
            this.SeriesClose.UseVisualStyleBackColor = false;
            this.SeriesClose.Click += new System.EventHandler(this.SeriesClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 25);
            this.label1.TabIndex = 20;
            this.label1.Text = "Series Selection";
            // 
            // Series_Selection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1115, 478);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SeriesClose);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Series_Selection";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Series_Selection";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void Seriesclose_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label Serieslabel1;
        private System.Windows.Forms.CheckBox SeriescheckBox4;
        private System.Windows.Forms.CheckBox SeriescheckBox7;
        private System.Windows.Forms.CheckBox SeriescheckBox8;
        private System.Windows.Forms.CheckBox SeriescheckBox6;
        private System.Windows.Forms.CheckBox SeriescheckBox5;
        private System.Windows.Forms.CheckBox SeriescheckBox3;
        private System.Windows.Forms.CheckBox SeriescheckBox2;
        private System.Windows.Forms.CheckBox SeriescheckBox1;
        private System.Windows.Forms.Label Serieslabel8;
        private System.Windows.Forms.Label Serieslabel7;
        private System.Windows.Forms.Label Serieslabel6;
        private System.Windows.Forms.Label Serieslabel4;
        private System.Windows.Forms.Label Serieslabel3;
        private System.Windows.Forms.Label Serieslabel2;
        private System.Windows.Forms.Label Serieslabel9;
        private System.Windows.Forms.Label Serieslabel10;
        private System.Windows.Forms.Label Serieslabel5;
        private System.Windows.Forms.CheckBox SeriescheckBox9;
        private System.Windows.Forms.CheckBox SeriescheckBox10;
        private System.Windows.Forms.Button SeriesClose;
        private System.Windows.Forms.Label label1;
    }
}