﻿
namespace Skillfull_Dashboard
{
    partial class Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AccountLabel = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.FromDateLabel = new System.Windows.Forms.Label();
            this.ToDateLabel = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.srNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salesPointsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.winningPointsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commissionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.netPointsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accountsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSet6 = new Skillfull_Dashboard.masterDataSet6();
            this.TotalSaleLabel = new System.Windows.Forms.Label();
            this.TotalWinningLabel = new System.Windows.Forms.Label();
            this.TotalCommissionLabel = new System.Windows.Forms.Label();
            this.NetPayLabel = new System.Windows.Forms.Label();
            this.TotalSaleValueLabel = new System.Windows.Forms.Label();
            this.TotalWinningValueLabel = new System.Windows.Forms.Label();
            this.TotalCommitionValueLabel = new System.Windows.Forms.Label();
            this.NetPayValueLabel = new System.Windows.Forms.Label();
            this.accountsTableAdapter = new Skillfull_Dashboard.masterDataSet6TableAdapters.AccountsTableAdapter();
            this.AccountCloseButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet6)).BeginInit();
            this.SuspendLayout();
            // 
            // AccountLabel
            // 
            this.AccountLabel.AutoSize = true;
            this.AccountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountLabel.Location = new System.Drawing.Point(22, 25);
            this.AccountLabel.Name = "AccountLabel";
            this.AccountLabel.Size = new System.Drawing.Size(91, 25);
            this.AccountLabel.TabIndex = 0;
            this.AccountLabel.Text = "Account";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(165, 83);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // FromDateLabel
            // 
            this.FromDateLabel.AutoSize = true;
            this.FromDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FromDateLabel.Location = new System.Drawing.Point(22, 83);
            this.FromDateLabel.Name = "FromDateLabel";
            this.FromDateLabel.Size = new System.Drawing.Size(107, 24);
            this.FromDateLabel.TabIndex = 2;
            this.FromDateLabel.Text = "From Date";
            // 
            // ToDateLabel
            // 
            this.ToDateLabel.AutoSize = true;
            this.ToDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToDateLabel.Location = new System.Drawing.Point(468, 84);
            this.ToDateLabel.Name = "ToDateLabel";
            this.ToDateLabel.Size = new System.Drawing.Size(89, 25);
            this.ToDateLabel.TabIndex = 3;
            this.ToDateLabel.Text = "To Date";
            this.ToDateLabel.Click += new System.EventHandler(this.ToDateLabel_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(584, 86);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker2.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.RoyalBlue;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(25, 142);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(187, 42);
            this.button1.TabIndex = 5;
            this.button1.Text = "Point Summary";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(258, 142);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(234, 42);
            this.button2.TabIndex = 6;
            this.button2.Text = "Point Summary Print";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.srNoDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.userNameDataGridViewTextBoxColumn,
            this.salesPointsDataGridViewTextBoxColumn,
            this.winningPointsDataGridViewTextBoxColumn,
            this.commissionDataGridViewTextBoxColumn,
            this.netPointsDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.accountsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(26, 201);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1002, 110);
            this.dataGridView1.TabIndex = 7;
            // 
            // srNoDataGridViewTextBoxColumn
            // 
            this.srNoDataGridViewTextBoxColumn.DataPropertyName = "SrNo";
            this.srNoDataGridViewTextBoxColumn.HeaderText = "SrNo";
            this.srNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.srNoDataGridViewTextBoxColumn.Name = "srNoDataGridViewTextBoxColumn";
            this.srNoDataGridViewTextBoxColumn.Width = 125;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.Width = 125;
            // 
            // userNameDataGridViewTextBoxColumn
            // 
            this.userNameDataGridViewTextBoxColumn.DataPropertyName = "User Name";
            this.userNameDataGridViewTextBoxColumn.HeaderText = "User Name";
            this.userNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.userNameDataGridViewTextBoxColumn.Name = "userNameDataGridViewTextBoxColumn";
            this.userNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // salesPointsDataGridViewTextBoxColumn
            // 
            this.salesPointsDataGridViewTextBoxColumn.DataPropertyName = "Sales Points";
            this.salesPointsDataGridViewTextBoxColumn.HeaderText = "Sales Points";
            this.salesPointsDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.salesPointsDataGridViewTextBoxColumn.Name = "salesPointsDataGridViewTextBoxColumn";
            this.salesPointsDataGridViewTextBoxColumn.Width = 125;
            // 
            // winningPointsDataGridViewTextBoxColumn
            // 
            this.winningPointsDataGridViewTextBoxColumn.DataPropertyName = "WinningPoints";
            this.winningPointsDataGridViewTextBoxColumn.HeaderText = "WinningPoints";
            this.winningPointsDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.winningPointsDataGridViewTextBoxColumn.Name = "winningPointsDataGridViewTextBoxColumn";
            this.winningPointsDataGridViewTextBoxColumn.Width = 125;
            // 
            // commissionDataGridViewTextBoxColumn
            // 
            this.commissionDataGridViewTextBoxColumn.DataPropertyName = "Commission";
            this.commissionDataGridViewTextBoxColumn.HeaderText = "Commission";
            this.commissionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.commissionDataGridViewTextBoxColumn.Name = "commissionDataGridViewTextBoxColumn";
            this.commissionDataGridViewTextBoxColumn.Width = 125;
            // 
            // netPointsDataGridViewTextBoxColumn
            // 
            this.netPointsDataGridViewTextBoxColumn.DataPropertyName = "Net Points";
            this.netPointsDataGridViewTextBoxColumn.HeaderText = "Net Points";
            this.netPointsDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.netPointsDataGridViewTextBoxColumn.Name = "netPointsDataGridViewTextBoxColumn";
            this.netPointsDataGridViewTextBoxColumn.Width = 125;
            // 
            // accountsBindingSource
            // 
            this.accountsBindingSource.DataMember = "Accounts";
            this.accountsBindingSource.DataSource = this.masterDataSet6;
            // 
            // masterDataSet6
            // 
            this.masterDataSet6.DataSetName = "masterDataSet6";
            this.masterDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // TotalSaleLabel
            // 
            this.TotalSaleLabel.AutoSize = true;
            this.TotalSaleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalSaleLabel.Location = new System.Drawing.Point(22, 332);
            this.TotalSaleLabel.Name = "TotalSaleLabel";
            this.TotalSaleLabel.Size = new System.Drawing.Size(100, 20);
            this.TotalSaleLabel.TabIndex = 8;
            this.TotalSaleLabel.Text = "TotalSale :";
            // 
            // TotalWinningLabel
            // 
            this.TotalWinningLabel.AutoSize = true;
            this.TotalWinningLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalWinningLabel.Location = new System.Drawing.Point(158, 332);
            this.TotalWinningLabel.Name = "TotalWinningLabel";
            this.TotalWinningLabel.Size = new System.Drawing.Size(124, 20);
            this.TotalWinningLabel.TabIndex = 9;
            this.TotalWinningLabel.Text = "Total Winning";
            // 
            // TotalCommissionLabel
            // 
            this.TotalCommissionLabel.AutoSize = true;
            this.TotalCommissionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalCommissionLabel.Location = new System.Drawing.Point(323, 332);
            this.TotalCommissionLabel.Name = "TotalCommissionLabel";
            this.TotalCommissionLabel.Size = new System.Drawing.Size(158, 20);
            this.TotalCommissionLabel.TabIndex = 10;
            this.TotalCommissionLabel.Text = "Total Commition :";
            // 
            // NetPayLabel
            // 
            this.NetPayLabel.AutoSize = true;
            this.NetPayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetPayLabel.Location = new System.Drawing.Point(516, 332);
            this.NetPayLabel.Name = "NetPayLabel";
            this.NetPayLabel.Size = new System.Drawing.Size(87, 20);
            this.NetPayLabel.TabIndex = 11;
            this.NetPayLabel.Text = "Net Pay :";
            // 
            // TotalSaleValueLabel
            // 
            this.TotalSaleValueLabel.AutoSize = true;
            this.TotalSaleValueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalSaleValueLabel.Location = new System.Drawing.Point(24, 371);
            this.TotalSaleValueLabel.Name = "TotalSaleValueLabel";
            this.TotalSaleValueLabel.Size = new System.Drawing.Size(0, 20);
            this.TotalSaleValueLabel.TabIndex = 12;
            this.TotalSaleValueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TotalWinningValueLabel
            // 
            this.TotalWinningValueLabel.AutoSize = true;
            this.TotalWinningValueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalWinningValueLabel.Location = new System.Drawing.Point(162, 371);
            this.TotalWinningValueLabel.Name = "TotalWinningValueLabel";
            this.TotalWinningValueLabel.Size = new System.Drawing.Size(0, 20);
            this.TotalWinningValueLabel.TabIndex = 13;
            this.TotalWinningValueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TotalCommitionValueLabel
            // 
            this.TotalCommitionValueLabel.AutoSize = true;
            this.TotalCommitionValueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalCommitionValueLabel.Location = new System.Drawing.Point(324, 371);
            this.TotalCommitionValueLabel.Name = "TotalCommitionValueLabel";
            this.TotalCommitionValueLabel.Size = new System.Drawing.Size(0, 20);
            this.TotalCommitionValueLabel.TabIndex = 14;
            this.TotalCommitionValueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NetPayValueLabel
            // 
            this.NetPayValueLabel.AutoSize = true;
            this.NetPayValueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetPayValueLabel.Location = new System.Drawing.Point(517, 371);
            this.NetPayValueLabel.Name = "NetPayValueLabel";
            this.NetPayValueLabel.Size = new System.Drawing.Size(0, 20);
            this.NetPayValueLabel.TabIndex = 15;
            this.NetPayValueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // accountsTableAdapter
            // 
            this.accountsTableAdapter.ClearBeforeFill = true;
            // 
            // AccountCloseButton
            // 
            this.AccountCloseButton.BackColor = System.Drawing.Color.DarkGray;
            this.AccountCloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountCloseButton.Location = new System.Drawing.Point(953, 357);
            this.AccountCloseButton.Name = "AccountCloseButton";
            this.AccountCloseButton.Size = new System.Drawing.Size(75, 41);
            this.AccountCloseButton.TabIndex = 16;
            this.AccountCloseButton.Text = "Close";
            this.AccountCloseButton.UseVisualStyleBackColor = false;
            this.AccountCloseButton.Click += new System.EventHandler(this.AccountCloseButton_Click);
            // 
            // Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1147, 410);
            this.Controls.Add(this.AccountCloseButton);
            this.Controls.Add(this.NetPayValueLabel);
            this.Controls.Add(this.TotalCommitionValueLabel);
            this.Controls.Add(this.TotalWinningValueLabel);
            this.Controls.Add(this.TotalSaleValueLabel);
            this.Controls.Add(this.NetPayLabel);
            this.Controls.Add(this.TotalCommissionLabel);
            this.Controls.Add(this.TotalWinningLabel);
            this.Controls.Add(this.TotalSaleLabel);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.ToDateLabel);
            this.Controls.Add(this.FromDateLabel);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.AccountLabel);
            this.Name = "Account";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Account";
            this.Load += new System.EventHandler(this.Account_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label AccountLabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label FromDateLabel;
        private System.Windows.Forms.Label ToDateLabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label TotalSaleLabel;
        private System.Windows.Forms.Label TotalWinningLabel;
        private System.Windows.Forms.Label TotalCommissionLabel;
        private System.Windows.Forms.Label NetPayLabel;
        private System.Windows.Forms.Label TotalSaleValueLabel;
        private System.Windows.Forms.Label TotalWinningValueLabel;
        private System.Windows.Forms.Label TotalCommitionValueLabel;
        private System.Windows.Forms.Label NetPayValueLabel;
        private masterDataSet6 masterDataSet6;
        private System.Windows.Forms.BindingSource accountsBindingSource;
        private masterDataSet6TableAdapters.AccountsTableAdapter accountsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn srNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn userNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salesPointsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn winningPointsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commissionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn netPointsDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button AccountCloseButton;
    }
}