﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Skillfull_Dashboard
{
    public partial class Account : Form
    {
        public Account()
        {
            InitializeComponent();
        }

        private void ToDateLabel_Click(object sender, EventArgs e)
        {

        }

        private void Account_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'masterDataSet6.Accounts' table. You can move, or remove it, as needed.
            this.accountsTableAdapter.Fill(this.masterDataSet6.Accounts);

        }

        private void AccountCloseButton_Click(object sender, EventArgs e)
        {

        }
    }
}
