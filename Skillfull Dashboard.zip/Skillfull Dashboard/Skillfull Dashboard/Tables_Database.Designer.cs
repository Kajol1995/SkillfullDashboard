﻿
using System;
using System.Windows.Forms;

namespace Skillfull_Dashboard
{
    partial class Tables_Database
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.loginBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterDataSet1 = new Skillfull_Dashboard.masterDataSet1();
            this.masterDataSet = new Skillfull_Dashboard.masterDataSet();
            this.reprintBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reprintTableAdapter = new Skillfull_Dashboard.masterDataSetTableAdapters.ReprintTableAdapter();
            this.loginTableAdapter = new Skillfull_Dashboard.masterDataSet1TableAdapters.LoginTableAdapter();
            this.masterDataSet2 = new Skillfull_Dashboard.masterDataSet2();
            this.passwordsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.passwordsTableAdapter = new Skillfull_Dashboard.masterDataSet2TableAdapters.PasswordsTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.useridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oldPasswordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.newPasswordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.masterDataSet3 = new Skillfull_Dashboard.masterDataSet3();
            this.passwordsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.passwordsTableAdapter1 = new Skillfull_Dashboard.masterDataSet3TableAdapters.PasswordsTableAdapter();
            this.masterDataSet4 = new Skillfull_Dashboard.masterDataSet4();
            this.loginBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.loginTableAdapter1 = new Skillfull_Dashboard.masterDataSet4TableAdapters.LoginTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.useridDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.masterDataSet5 = new Skillfull_Dashboard.masterDataSet5();
            this.loginBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.loginTableAdapter2 = new Skillfull_Dashboard.masterDataSet5TableAdapters.LoginTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reprintBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // loginBindingSource
            // 
            this.loginBindingSource.DataMember = "Login";
            this.loginBindingSource.DataSource = this.masterDataSet1;
            // 
            // masterDataSet1
            // 
            this.masterDataSet1.DataSetName = "masterDataSet1";
            this.masterDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // masterDataSet
            // 
            this.masterDataSet.DataSetName = "masterDataSet";
            this.masterDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reprintBindingSource
            // 
            this.reprintBindingSource.DataMember = "Reprint";
            this.reprintBindingSource.DataSource = this.masterDataSet;
            // 
            // reprintTableAdapter
            // 
            this.reprintTableAdapter.ClearBeforeFill = true;
            // 
            // loginTableAdapter
            // 
            this.loginTableAdapter.ClearBeforeFill = true;
            // 
            // masterDataSet2
            // 
            this.masterDataSet2.DataSetName = "masterDataSet2";
            this.masterDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // passwordsBindingSource
            // 
            this.passwordsBindingSource.DataMember = "Passwords";
            this.passwordsBindingSource.DataSource = this.masterDataSet2;
            // 
            // passwordsTableAdapter
            // 
            this.passwordsTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.useridDataGridViewTextBoxColumn,
            this.oldPasswordDataGridViewTextBoxColumn,
            this.newPasswordDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.passwordsBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(721, 106);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(429, 246);
            this.dataGridView1.TabIndex = 0;
            // 
            // useridDataGridViewTextBoxColumn
            // 
            this.useridDataGridViewTextBoxColumn.DataPropertyName = "Userid";
            this.useridDataGridViewTextBoxColumn.HeaderText = "Userid";
            this.useridDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.useridDataGridViewTextBoxColumn.Name = "useridDataGridViewTextBoxColumn";
            this.useridDataGridViewTextBoxColumn.Width = 125;
            // 
            // oldPasswordDataGridViewTextBoxColumn
            // 
            this.oldPasswordDataGridViewTextBoxColumn.DataPropertyName = "OldPassword";
            this.oldPasswordDataGridViewTextBoxColumn.HeaderText = "OldPassword";
            this.oldPasswordDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.oldPasswordDataGridViewTextBoxColumn.Name = "oldPasswordDataGridViewTextBoxColumn";
            this.oldPasswordDataGridViewTextBoxColumn.Width = 125;
            // 
            // newPasswordDataGridViewTextBoxColumn
            // 
            this.newPasswordDataGridViewTextBoxColumn.DataPropertyName = "NewPassword";
            this.newPasswordDataGridViewTextBoxColumn.HeaderText = "NewPassword";
            this.newPasswordDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.newPasswordDataGridViewTextBoxColumn.Name = "newPasswordDataGridViewTextBoxColumn";
            this.newPasswordDataGridViewTextBoxColumn.Width = 125;
            // 
            // masterDataSet3
            // 
            this.masterDataSet3.DataSetName = "masterDataSet3";
            this.masterDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // passwordsBindingSource1
            // 
            this.passwordsBindingSource1.DataMember = "Passwords";
            this.passwordsBindingSource1.DataSource = this.masterDataSet3;
            // 
            // passwordsTableAdapter1
            // 
            this.passwordsTableAdapter1.ClearBeforeFill = true;
            // 
            // masterDataSet4
            // 
            this.masterDataSet4.DataSetName = "masterDataSet4";
            this.masterDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loginBindingSource1
            // 
            this.loginBindingSource1.DataMember = "Login";
            this.loginBindingSource1.DataSource = this.masterDataSet4;
            // 
            // loginTableAdapter1
            // 
            this.loginTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.useridDataGridViewTextBoxColumn1,
            this.passwordDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.loginBindingSource2;
            this.dataGridView2.Location = new System.Drawing.Point(198, 73);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(352, 150);
            this.dataGridView2.TabIndex = 1;
            // 
            // useridDataGridViewTextBoxColumn1
            // 
            this.useridDataGridViewTextBoxColumn1.DataPropertyName = "Userid";
            this.useridDataGridViewTextBoxColumn1.HeaderText = "Userid";
            this.useridDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.useridDataGridViewTextBoxColumn1.Name = "useridDataGridViewTextBoxColumn1";
            this.useridDataGridViewTextBoxColumn1.Width = 125;
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "Password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "Password";
            this.passwordDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            this.passwordDataGridViewTextBoxColumn.Width = 125;
            // 
            // masterDataSet5
            // 
            this.masterDataSet5.DataSetName = "masterDataSet5";
            this.masterDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loginBindingSource2
            // 
            this.loginBindingSource2.DataMember = "Login";
            this.loginBindingSource2.DataSource = this.masterDataSet5;
            // 
            // loginTableAdapter2
            // 
            this.loginTableAdapter2.ClearBeforeFill = true;
            // 
            // Reprint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1244, 605);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Reprint";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reprint ";
            this.Load += new System.EventHandler(this.Reprint_Load);
            ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reprintBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginBindingSource2)).EndInit();
            this.ResumeLayout(false);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion
        private masterDataSet masterDataSet;
        private System.Windows.Forms.BindingSource reprintBindingSource;
        private masterDataSetTableAdapters.ReprintTableAdapter reprintTableAdapter;
        private masterDataSet1 masterDataSet1;
        private System.Windows.Forms.BindingSource loginBindingSource;
        private masterDataSet1TableAdapters.LoginTableAdapter loginTableAdapter;
        private masterDataSet2 masterDataSet2;
        private BindingSource passwordsBindingSource;
        private masterDataSet2TableAdapters.PasswordsTableAdapter passwordsTableAdapter;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn useridDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn oldPasswordDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn newPasswordDataGridViewTextBoxColumn;
        private masterDataSet3 masterDataSet3;
        private BindingSource passwordsBindingSource1;
        private masterDataSet3TableAdapters.PasswordsTableAdapter passwordsTableAdapter1;
        private masterDataSet4 masterDataSet4;
        private BindingSource loginBindingSource1;
        private masterDataSet4TableAdapters.LoginTableAdapter loginTableAdapter1;
        private DataGridView dataGridView2;
        private DataGridViewTextBoxColumn useridDataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private masterDataSet5 masterDataSet5;
        private BindingSource loginBindingSource2;
        private masterDataSet5TableAdapters.LoginTableAdapter loginTableAdapter2;
    }
}