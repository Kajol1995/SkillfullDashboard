﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Skillfull_Dashboard
{
    public partial class Login_Page : Form
    {
        public Login_Page()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            // Select Command :
            
                string connetionString;
                SqlConnection con;
             connetionString = @"Data Source = Kajol1995; Initial Catalog = master; Integrated Security = True";

            con = new SqlConnection(connetionString);
                con.Open();

                /*MessageBox.Show("Connection Open  !");*/

                SqlCommand command;
                SqlDataAdapter adapter = new SqlDataAdapter();
            //  string sql = "Insert into Passwords(Userid, OldPassword, NewPassword) values('" + textBox3.Text + "', '" + textBox4.Text + "', '" + textBox5.Text + "')";

            string sql = "Select Userid, NewPassword from Passwords";
     
            command = new SqlCommand(sql, con);
             

            if(Username.Text == "RT0011"   && LoginPassword.Text== "abc@123")
            {
                MessageBox.Show("Login");
               
            }

            else
            {
                MessageBox.Show("Invalid Login");
            }
            //  adapter.InsertCommand = new SqlCommand(sql, con);
            // adapter.InsertCommand.ExecuteNonQuery();

            adapter.SelectCommand = new SqlCommand(sql, con);
            adapter.SelectCommand.ExecuteNonQuery();

                command.Dispose();
                con.Close();

            /*Reprint rp1 = new Reprint();
            rp1.Show();*/

           

            }
            



              /*  Insert Command :
               *  string connetionString;
                SqlConnection con;
                connetionString = @"Data Source = Kajol1995; Initial Catalog = master; Integrated Security = True";

                con = new SqlConnection(connetionString);
                con.Open();

                /*MessageBox.Show("Connection Open  !");

                SqlCommand command;
                SqlDataAdapter adapter = new SqlDataAdapter();
                string sql = "Insert into Login(Userid, Password) values('" + Username.Text + "', '" + LoginPassword.Text + "')";
                command = new SqlCommand(sql, con);

                adapter.InsertCommand = new SqlCommand(sql, con);
                adapter.InsertCommand.ExecuteNonQuery();

                command.Dispose();
                con.Close();
            */
             /* Reprint rp1 = new Reprint();
            rp1.Show();*/

            }

      /*  private void LoginPassword_TextChanged(object sender, EventArgs e)
        {
            LoginPassword.UseSystemPasswordChar = true;
            this.Controls.Add(LoginPassword);
        }*/

      /*  private void LoginPassword_TextChanged_1(object sender, EventArgs e)
        {

        }*/
    }
    

