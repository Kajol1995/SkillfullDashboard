﻿
using System;

namespace Skillfull_Dashboard
{
    partial class Result
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.Result_Submit = new System.Windows.Forms.Button();
            this.Result_Close = new System.Windows.Forms.Button();
            this.ResultLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Date :";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(130, 78);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 30);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(398, 78);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 30);
            this.dateTimePicker2.TabIndex = 2;
            this.dateTimePicker2.Value = new System.DateTime(2021, 11, 30, 1, 55, 0, 0);
            this.dateTimePicker2.Visible = false;
            // 
            // Result_Submit
            // 
            this.Result_Submit.BackColor = System.Drawing.Color.CornflowerBlue;
            this.Result_Submit.Location = new System.Drawing.Point(562, 181);
            this.Result_Submit.Name = "Result_Submit";
            this.Result_Submit.Size = new System.Drawing.Size(95, 42);
            this.Result_Submit.TabIndex = 3;
            this.Result_Submit.Text = "Submit";
            this.Result_Submit.UseVisualStyleBackColor = false;
            this.Result_Submit.Click += new System.EventHandler(this.Result_Submit_Click);
            // 
            // Result_Close
            // 
            this.Result_Close.BackColor = System.Drawing.Color.DarkGray;
            this.Result_Close.Location = new System.Drawing.Point(675, 181);
            this.Result_Close.Name = "Result_Close";
            this.Result_Close.Size = new System.Drawing.Size(75, 42);
            this.Result_Close.TabIndex = 4;
            this.Result_Close.Text = "Close";
            this.Result_Close.UseVisualStyleBackColor = false;
            this.Result_Close.Click += new System.EventHandler(this.Result_Close_Click);
            // 
            // ResultLabel
            // 
            this.ResultLabel.AutoSize = true;
            this.ResultLabel.Location = new System.Drawing.Point(12, 9);
            this.ResultLabel.Name = "ResultLabel";
            this.ResultLabel.Size = new System.Drawing.Size(64, 23);
            this.ResultLabel.TabIndex = 5;
            this.ResultLabel.Text = "Result";
            // 
            // Result
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(771, 244);
            this.Controls.Add(this.ResultLabel);
            this.Controls.Add(this.Result_Close);
            this.Controls.Add(this.Result_Submit);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Result";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Result";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void Result_Submit_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Button Result_Submit;
        private System.Windows.Forms.Button Result_Close;
        private System.Windows.Forms.Label ResultLabel;
    }
}