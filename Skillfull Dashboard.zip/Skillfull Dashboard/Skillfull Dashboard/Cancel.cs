﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Skillfull_Dashboard
{
    public partial class Cancel : Form
    {
        public Cancel()
        {
            InitializeComponent();
        }

        private void Cancel_Submit_Click(object sender, EventArgs e)
        {

        }
    }
}
