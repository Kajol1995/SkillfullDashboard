﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Skillfull_Dashboard
{
    public partial class Tables_Database : Form
    {
        public Tables_Database()
        {
            InitializeComponent();
        }

        private void Reprint_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'masterDataSet5.Login' table. You can move, or remove it, as needed.
            this.loginTableAdapter2.Fill(this.masterDataSet5.Login);
            // TODO: This line of code loads data into the 'masterDataSet3.Passwords' table. You can move, or remove it, as needed.
            this.passwordsTableAdapter1.Fill(this.masterDataSet3.Passwords);
            // TODO: This line of code loads data into the 'masterDataSet2.Passwords' table. You can move, or remove it, as needed.
            this.passwordsTableAdapter.Fill(this.masterDataSet2.Passwords);
             // TODO: This line of code loads data into the 'masterDataSet.Reprint' table. You can move, or remove it, as needed.
            this.reprintTableAdapter.Fill(this.masterDataSet.Reprint);

        }

       

        /*private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            
             /*   string connetionString;
                SqlConnection con;
                connetionString = @"Data Source = Kajol1995; Initial Catalog = master; Integrated Security = True";
            
                con = new SqlConnection(connetionString);
                con.Open();

                /*MessageBox.Show("Connection Open  !");

                SqlCommand command;
                SqlDataAdapter adapter = new SqlDataAdapter();
                string sql = "Insert into Passwords(Userid, OldPassword, NewPassword) values('" + textBox3.Text + "', '" + textBox4.Text + "', '" + textBox5.Text + "')";
                command = new SqlCommand(sql, con);

                adapter.InsertCommand = new SqlCommand(sql, con);
                adapter.InsertCommand.ExecuteNonQuery();

                command.Dispose();
                con.Close();

            }*/

        }
    }

