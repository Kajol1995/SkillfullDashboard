﻿INSERT INTO [dbo].[Reprint] ([Sr.No], [DrawDate], [DrawTime], [TicketNo], [PlayPoints]) VALUES (NULL, NULL, NULL, NULL, NULL)
