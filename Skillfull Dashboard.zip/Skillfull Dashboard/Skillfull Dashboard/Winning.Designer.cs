﻿
namespace Skillfull_Dashboard
{
    partial class Winning
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Winning_Label = new System.Windows.Forms.Label();
            this.WinningClose = new System.Windows.Forms.Button();
            this.Winning_dataGridView1 = new System.Windows.Forms.DataGridView();
            this.SrNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ticket = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Points = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Winning_dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Winning_Label
            // 
            this.Winning_Label.AutoSize = true;
            this.Winning_Label.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Winning_Label.Location = new System.Drawing.Point(50, 190);
            this.Winning_Label.Name = "Winning_Label";
            this.Winning_Label.Size = new System.Drawing.Size(257, 27);
            this.Winning_Label.TabIndex = 3;
            this.Winning_Label.Text = "Ticket is already Scanned";
            // 
            // WinningClose
            // 
            this.WinningClose.BackColor = System.Drawing.Color.DarkGray;
            this.WinningClose.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WinningClose.Location = new System.Drawing.Point(523, 216);
            this.WinningClose.Name = "WinningClose";
            this.WinningClose.Size = new System.Drawing.Size(75, 45);
            this.WinningClose.TabIndex = 4;
            this.WinningClose.Text = "Close";
            this.WinningClose.UseVisualStyleBackColor = false;
            this.WinningClose.Click += new System.EventHandler(this.WinningClose_Click);
            // 
            // Winning_dataGridView1
            // 
            this.Winning_dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.Winning_dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Winning_dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SrNo,
            this.Ticket,
            this.Points});
            this.Winning_dataGridView1.GridColor = System.Drawing.Color.Black;
            this.Winning_dataGridView1.Location = new System.Drawing.Point(55, 12);
            this.Winning_dataGridView1.Name = "Winning_dataGridView1";
            this.Winning_dataGridView1.RowHeadersWidth = 51;
            this.Winning_dataGridView1.RowTemplate.Height = 24;
            this.Winning_dataGridView1.Size = new System.Drawing.Size(561, 150);
            this.Winning_dataGridView1.TabIndex = 5;
            // 
            // SrNo
            // 
            this.SrNo.HeaderText = "SrNo";
            this.SrNo.MinimumWidth = 6;
            this.SrNo.Name = "SrNo";
            this.SrNo.Width = 125;
            // 
            // Ticket
            // 
            this.Ticket.HeaderText = "Ticket";
            this.Ticket.MinimumWidth = 6;
            this.Ticket.Name = "Ticket";
            this.Ticket.Width = 125;
            // 
            // Points
            // 
            this.Points.HeaderText = "Points";
            this.Points.MinimumWidth = 6;
            this.Points.Name = "Points";
            this.Points.Width = 125;
            // 
            // Winning
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(659, 269);
            this.Controls.Add(this.Winning_dataGridView1);
            this.Controls.Add(this.WinningClose);
            this.Controls.Add(this.Winning_Label);
            this.Name = "Winning";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Winning";
            ((System.ComponentModel.ISupportInitialize)(this.Winning_dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Winning_Label;
        private System.Windows.Forms.Button WinningClose;
        private System.Windows.Forms.DataGridView Winning_dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SrNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ticket;
        private System.Windows.Forms.DataGridViewTextBoxColumn Points;
    }
}

