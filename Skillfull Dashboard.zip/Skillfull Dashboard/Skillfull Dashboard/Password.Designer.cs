﻿
using System;

namespace Skillfull_Dashboard
{
    partial class Password
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pwd_Userid = new System.Windows.Forms.Label();
            this.pwd_oldpassword = new System.Windows.Forms.Label();
            this.pwd_newpassword = new System.Windows.Forms.Label();
            this.PwdSubmit = new System.Windows.Forms.Button();
            this.PwdClose = new System.Windows.Forms.Button();
            this.pwduserid = new System.Windows.Forms.TextBox();
            this.pwdoldpassword = new System.Windows.Forms.TextBox();
            this.newpassword = new System.Windows.Forms.TextBox();
            this.ChangePwdLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Pwd_Userid
            // 
            this.Pwd_Userid.AutoSize = true;
            this.Pwd_Userid.Location = new System.Drawing.Point(16, 57);
            this.Pwd_Userid.Name = "Pwd_Userid";
            this.Pwd_Userid.Size = new System.Drawing.Size(67, 23);
            this.Pwd_Userid.TabIndex = 0;
            this.Pwd_Userid.Text = "UserId";
            // 
            // pwd_oldpassword
            // 
            this.pwd_oldpassword.AutoSize = true;
            this.pwd_oldpassword.Location = new System.Drawing.Point(16, 120);
            this.pwd_oldpassword.Name = "pwd_oldpassword";
            this.pwd_oldpassword.Size = new System.Drawing.Size(126, 23);
            this.pwd_oldpassword.TabIndex = 1;
            this.pwd_oldpassword.Text = "Old Password";
            // 
            // pwd_newpassword
            // 
            this.pwd_newpassword.AutoSize = true;
            this.pwd_newpassword.Location = new System.Drawing.Point(16, 182);
            this.pwd_newpassword.Name = "pwd_newpassword";
            this.pwd_newpassword.Size = new System.Drawing.Size(133, 23);
            this.pwd_newpassword.TabIndex = 2;
            this.pwd_newpassword.Text = "New Password";
            // 
            // PwdSubmit
            // 
            this.PwdSubmit.BackColor = System.Drawing.Color.CornflowerBlue;
            this.PwdSubmit.Location = new System.Drawing.Point(682, 252);
            this.PwdSubmit.Name = "PwdSubmit";
            this.PwdSubmit.Size = new System.Drawing.Size(90, 41);
            this.PwdSubmit.TabIndex = 3;
            this.PwdSubmit.Text = "Submit";
            this.PwdSubmit.UseVisualStyleBackColor = false;
            this.PwdSubmit.Click += new System.EventHandler(this.PwdSubmit_Click);
            // 
            // PwdClose
            // 
            this.PwdClose.BackColor = System.Drawing.Color.DarkGray;
            this.PwdClose.Location = new System.Drawing.Point(778, 252);
            this.PwdClose.Name = "PwdClose";
            this.PwdClose.Size = new System.Drawing.Size(93, 41);
            this.PwdClose.TabIndex = 4;
            this.PwdClose.Text = "Close";
            this.PwdClose.UseVisualStyleBackColor = false;
            this.PwdClose.Click += new System.EventHandler(this.PwdClose_Click);
            // 
            // pwduserid
            // 
            this.pwduserid.Enabled = false;
            this.pwduserid.Location = new System.Drawing.Point(312, 40);
            this.pwduserid.Multiline = true;
            this.pwduserid.Name = "pwduserid";
            this.pwduserid.Size = new System.Drawing.Size(559, 40);
            this.pwduserid.TabIndex = 5;
            // 
            // pwdoldpassword
            // 
            this.pwdoldpassword.Location = new System.Drawing.Point(312, 103);
            this.pwdoldpassword.Multiline = true;
            this.pwdoldpassword.Name = "pwdoldpassword";
            this.pwdoldpassword.Size = new System.Drawing.Size(559, 40);
            this.pwdoldpassword.TabIndex = 6;
            this.pwdoldpassword.UseSystemPasswordChar = true;
            // 
            // newpassword
            // 
            this.newpassword.Location = new System.Drawing.Point(312, 165);
            this.newpassword.Multiline = true;
            this.newpassword.Name = "newpassword";
            this.newpassword.Size = new System.Drawing.Size(559, 40);
            this.newpassword.TabIndex = 7;
            // 
            // ChangePwdLabel
            // 
            this.ChangePwdLabel.AutoSize = true;
            this.ChangePwdLabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangePwdLabel.Location = new System.Drawing.Point(12, 9);
            this.ChangePwdLabel.Name = "ChangePwdLabel";
            this.ChangePwdLabel.Size = new System.Drawing.Size(159, 23);
            this.ChangePwdLabel.TabIndex = 8;
            this.ChangePwdLabel.Text = "Change Password";
            // 
            // Password
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(902, 305);
            this.Controls.Add(this.ChangePwdLabel);
            this.Controls.Add(this.newpassword);
            this.Controls.Add(this.pwdoldpassword);
            this.Controls.Add(this.pwduserid);
            this.Controls.Add(this.PwdClose);
            this.Controls.Add(this.PwdSubmit);
            this.Controls.Add(this.pwd_newpassword);
            this.Controls.Add(this.pwd_oldpassword);
            this.Controls.Add(this.Pwd_Userid);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Password";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Change Password";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        /*private void pwdnewpassword_TextChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }*/

        /*  private void pwdnewpassword_TextChanged(object sender, EventArgs e)
          {
              throw new NotImplementedException();
          }*/

        #endregion

        private System.Windows.Forms.Label Pwd_Userid;
        private System.Windows.Forms.Label pwd_oldpassword;
        private System.Windows.Forms.Label pwd_newpassword;
        private System.Windows.Forms.Button PwdSubmit;
        private System.Windows.Forms.Button PwdClose;
        private System.Windows.Forms.TextBox pwduserid;
        private System.Windows.Forms.TextBox pwdoldpassword;
        private System.Windows.Forms.TextBox newpassword;
        private System.Windows.Forms.Label ChangePwdLabel;
    }
}