﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Skillfull_Dashboard
{
    public partial class Password : Form
    {
        public Password()
        {
            InitializeComponent();
        }
       
        private void PwdSubmit_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection con;
            connetionString = @"Data Source = Kajol1995; Initial Catalog = master; Integrated Security = True";

            con = new SqlConnection(connetionString);
            con.Open();

            /*MessageBox.Show("Connection Open  !");*/

            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql = "Insert into Passwords(Userid, OldPassword, NewPassword) values('" + pwduserid.Text + "', '" + pwdoldpassword.Text + "', '" + newpassword.Text + "')";
            command = new SqlCommand(sql, con);

            adapter.InsertCommand = new SqlCommand(sql, con);
            _ = adapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
            con.Close();

           
        }

        private void PwdClose_Click(object sender, EventArgs e)
        {
           
        }
    }
}

