﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Skillfull_Dashboard
{
    public partial class Winning : Form
    {
        public Winning()
        {
            InitializeComponent();
        }

        private void WinningClose_Click(object sender, EventArgs e)
        {

        }
    }
}
